-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require("widget")
local input1 = native.newTextField( 370, 80, 230, 40)
local input2 = native.newTextField( 370, 200, 230, 40)
local flatRect1 = display.newRect(250, 240, 480, 5)
local flatRect2 = display.newRect(250, 240, 480, 5)
flatRect1: setFillColor(1, 1, 1)
flatRect2: setFillColor(1, 1, 1)
local textAnswer = display.newText("???", 450, 40, native.systemFont, 32)
textAnswer.x = 250
textAnswer.y = 270

local addHandler =function(event)
      textAnswer.text = input1.text + input2.text
end

local button1 = widget.newButton
{
	label = "+",
	shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
	   over = {0.6, 0.6, 0.6},
	 },
	 labelColor =
 	 {
		default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = addHandler, 
	 width = 45,
}

local subHandler =function(event)
      textAnswer.text = input1.text - input2.text
end

local button2 = widget.newButton
{
  label = "-",
  shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
     over = {0.6, 0.6, 0.6},
   },
   labelColor =
   {
    default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = subHandler, 
   width = 45,
}

local divHandler =function(event)
      textAnswer.text = input1.text / input2.text
end

local button3 = widget.newButton
{
  label = "/",
  shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
     over = {0.6, 0.6, 0.6},
   },
   labelColor =
   {
    default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = divHandler, 
   width = 45,
}

local multHandler =function(event)
      textAnswer.text = input1.text * input2.text
end

local button4 = widget.newButton
{
  label = "*",
  shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
     over = {0.6, 0.6, 0.6},
   },
   labelColor =
   {
    default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = multHandler, 
   width = 45,
}

button1.x = 30
button1.y = 160

button2.x = 30
button2.y = 60

button3.x = 90
button3.y = 160

button4.x = 90
button4.y = 60








