-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require("widget")

local input1 = native.newTextField(370, 80, 230, 40)
local input2 = native.newTextField(370, 150, 230, 40)

local flatRect = display.newRect(250, 240, 480, 5)
flatRect:setFillColor(1, 1, 1)

local textAnswer = display.newText("???", 450, 40, native.systemFont, 32)	
textAnswer.x = 250
textAnswer.y = 270

local addHandler = function(event)
	textAnswer.text = input1.text + input2.text
end

local addButton = widget.newButton
{
	label = "+",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = addHandler,
	width = 45,
}

addButton.x = 30
addButton.y = 160

local subtractHandler = function(event)
	textAnswer.text = input1.text - input2.text
end

local subtractButton = widget.newButton
{
	label = "-",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = subtractHandler,
	width = 45,
}

subtractButton.x = 80
subtractButton.y = 160

local multiplyHandler = function(event)
	textAnswer.text = input1.text * input2.text
end

local multiplyButton = widget.newButton
{
	label = "x",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = multiplyHandler,
	width = 45,
}

multiplyButton.x = 130
multiplyButton.y = 160

local divideHandler = function(event)
	textAnswer.text = input1.text / input2.text
end

local divideButton = widget.newButton
{
	label = "/",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = divideHandler,
	width = 45,
}

divideButton.x = 180
divideButton.y = 160