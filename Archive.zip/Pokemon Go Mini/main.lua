-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

display.setStatusBar(display.DefaultStatusBar)

local catchCount = 0
local answerText = display.newText("Pokemon Count: "..catchCount, 200, 40, native.systemFont, 50)
answerText.x = 250
answerText.y = 900

local myMap = native.newMapView(250, 500, 500, 1000)

local currentLat = 0
local currentLon = 0

local function mapmarker(event)
	local opt1 =
	{
		imageFile = "images/c001.png",
	}
	myMap: addMarker(-0.0017 + currentLat, -0.0017 + currentLon, opt1)

	local opt2 =
	{
		imageFile = "images/c007.png",
	}
	myMap: addMarker(0.0019 + currentLat, -0.0013 + currentLon, opt2)

	local opt3 =
	{
		imageFile = "images/c0012.png",
	}
	myMap: addMarker(0.0018 + currentLat, 0.0018 + currentLon, opt3)

	local opt4 =
	{
		imageFile = "images/c0023.png",
	}
	myMap: addMarker(-0.0037 + currentLat, -0.0006 + currentLon, opt4)


	local opt5 =
	{
		imageFile = "images/c0039.png",
	}
	myMap: addMarker(0.004 + currentLat, -0.0027 + currentLon, opt5)

end


if myMap then
	myMap.mapType = "normal"

	--need to delay so marker can appear after map is ready
	timer.performWithDelay(5000, mapmarker)
end

local function locationEventHandler(event)
	if event then 
		myMap:setRegion(event.latitude, event.longitude, 0.01, 0.01)
	end
	currentLat = event.latitude
	currentLon = event.longitude
end

Runtime:addEventListener("location", locationEventHandler)