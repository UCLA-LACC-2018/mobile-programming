-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

display.setStatusBar(displayDefaultStatusBar)

local input1 = native.newTextField(250,400,200,40)
local input2 = native.newTextField(250,500,200,40)

local answerText =display.newText("???", 200,40,native.systemFont,32) --initial text, width, height, font, fontsize
answerText.x = 250
answerText.y = 600

-- button1 (plus)
local addHandler = function(event)
	answerText.text = input1.text + input2.text
end

local button1 = widget.newButton
{
	label = "+",
	shape = "roundRect",
	fillColor = 
	{
		default = {1, 0.5, 0.5},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = addHandler,
}

button1.x = 160
button1.y = 180


-- button2 (minus)
local addHandler2 = function(event)
	answerText.text = input1.text - input2.text
end

local button2 = widget.newButton
{
	label = "-",
	shape = "roundRect",
	fillColor = 
	{
		default = {1, 0.5, 0.5},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = addHandler2,
}

button2.x = 340
button2.y = 180


-- button3 (multiply)
local addHandler3 = function(event)
	answerText.text = input1.text * input2.text
end

local button3 = widget.newButton
{
	label = "*",
	shape = "roundRect",
	fillColor = 
	{
		default = {1, 0.5, 0.5},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = addHandler3,
}

button3.x = 160
button3.y = 260


-- button4 (divide)
local addHandler4 = function(event)
	answerText.text = input1.text / input2.text
end

local button4 = widget.newButton
{
	label = "/",
	shape = "roundRect",
	fillColor = 
	{
		default = {1, 0.5, 0.5},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = addHandler4,
}

button4.x = 340
button4.y = 260