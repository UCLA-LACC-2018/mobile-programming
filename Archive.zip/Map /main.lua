-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

local myMap = native.newMapView(250, 500, 500, 1000)

local function mapmarker(event)
	local opt1 =
	{
		title = "Chick-fil-A",
		subtitle = "Discount on Monday evenings"
	}
	myMap: addMarker(34.063327, -118.445130, opt1)

	local opt2 =
	{
		title = "McDonald's",
		subtitle = "Our ice cream machine is working!"
	}
	myMap: addMarker(34.086190, -118.0408376, opt2)
end


if myMap then
	myMap.mapType = "normal"

	--need to delay so marker can appear after map is ready
	timer.performWithDelay(5000, mapmarker)
end

local function locationEventHandler(event)
	if event then 
		myMap:setRegion(event.latitude, event.longitude, 0.01, 0.01)
	end
end

Runtime:addEventListener("location", locationEventHandler)