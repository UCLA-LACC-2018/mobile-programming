-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

display.setStatusBar(display.DefaultStatusBar)

local filePath = system.pathForFile("data.txt", system.DocumentsDirectory)

local input = native.newTextBox(250, 280, 480, 480)
input.isEditable = true

local count = 0

local loadingFile = function(event)
	file = io.open(filePath, "r")
	if file then
		local content = file:read("*a")
		io.close(file)
		input.text = content
	end
end

local savingFile = function(event)

	file = io.open(filePath, "w")
	if file then
		local content = file:write(input.text)
		io.close(file)
	end
end

local saveButton = widget.newButton
{
	label = "Save",
	shape = "roundRect",
	fillColor = 
	{
		default = {0.5, 0.5, 1},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = savingFile
}

saveButton.x = 360
saveButton.y = 580

local loadButton = widget.newButton
{
	label = "Load",
	shape = "roundRect",
	fillColor = 
	{
		default = {0.5, 0.5, 1},
		over = {0.6, 0.6, 0.6}
	},
	labelColor = 
	{
		default = {1, 1, 1},
	},
	fontSize = 30, 
	font = native.systemFont,
	width = 45,

	onRelease = loadingFile,
}

loadButton.x = 140
loadButton.y = 580