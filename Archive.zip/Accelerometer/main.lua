-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

system.setAccelerometerInterval(60)

local textGravX = display.newText("Gravity X: ", 180, 280, native.systemFont, 30)
local textGravY = display.newText("Gravity Y: ", 180, 350, native.systemFont, 30)
local textGravZ = display.newText("Gravity Z: ", 180, 420, native.systemFont, 30)

local textInstantX = display.newText("Instant X: ", 180, 540, native.systemFont, 30)
local textInstantY = display.newText("Instant Y: ", 180, 610, native.systemFont, 30)
local textInstantZ = display.newText("Instant Z: ", 180, 680, native.systemFont, 30)

local onAccelerate = function(event)
	textGravX.text = "Gravity X: " .. event.xGravity
	textGravY.text = "Gravity Y: " .. event.yGravity
	textGravZ.text = "Gravity Z: " .. event.zGravity
	textInstantX.text = "Instant X: " .. event.xInstant
	textInstantY.text = "Instant Y: " .. event.yInstant
	textInstantZ.text = "Instant Z: " .. event.zInstant

--	if event.isShake == true then
--		toggleColor()
end
	
Runtime: addEventListener("accelerometer", onAccelerate)
