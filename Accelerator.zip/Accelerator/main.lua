-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local textGravX = display.newText("?", 200, 50, native.systemFont, 32)
local textGravY = display.newText("?", 200, 50, native.systemFont, 32)
local textGravZ = display.newText("?", 200, 50, native.systemFont, 32)
local textInstantX = display.newText("?", 200, 50, native.systemFont, 32)
local textInstantY = display.newText("?", 200, 50, native.systemFont, 32)
local textInstantZ = display.newText("?", 200, 50, native.systemFont, 32)

textGravX.x = 30
textGravX.y = 50
textGravY.x = 30
textGravY.y = 100
textGravZ.x = 30
textGravZ.y = 150
textInstantX.x = 30
textInstantX.y = 200
textInstantY.x = 30
textInstantY.y =250
textInstantZ.x = 30
textInstantZ.y = 300



system.setAccelerometerInterval(60)

local onAccelerate = function(event)
	textGravX.text = "Gravity X: " .. event.xGravity
	textGravY.text = "Gravity Y: " .. event.yGravity
	textGravZ.text = "Gravity Z: " .. event.zGravity
	textInstantX.text = "Instant X: " .. event.xInstant
	textInstantY.text = "Instant Y: " .. event.yInstant
	textInstantZ.text = "Instant Z: " .. event.zInstant

end

Runtime:addEventListener("accelerometer", onAccelerate)

