-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local textGravX = display.newText("Gravity X:", 450, 40, native.systemFont, 32)
textGravX.x = 250
textGravX.y = 200
local textGravY = display.newText("Gravity Y:", 450, 40, native.systemFont, 32)
textGravY.x = 250
textGravY.y = 230
local textGravZ = display.newText("Gravity Z:", 450, 40, native.systemFont, 32)
textGravZ.x = 250
textGravZ.y = 260
local textInstantX = display.newText("Instant X:", 450, 40, native.systemFont, 32)
textInstantX.x = 250
textInstantX.y = 290
local textInstantY = display.newText("Instant Y:", 450, 40, native.systemFont, 32)
textInstantY.x = 250
textInstantY.y = 320
local textInstantZ = display.newText("Instant Z:", 450, 40, native.systemFont, 32)
textInstantZ.x = 250
textInstantZ.y = 350

local shakeIndicator = display.newRect(250, 500, 480, 100)
shakeIndicator:setFillColor(0, 0, 0)

local onAccelerate = function(event)
	textGravX.text = "Gravity X: " .. event.xGravity
	textGravY.text = "Gravity Y: " .. event.yGravity
	textGravZ.text = "Gravity Z: " .. event.zGravity
	textInstantX.text = "Instant X: " .. event.xInstant
	textInstantY.text = "Instant Y: " .. event.yInstant
	textInstantZ.text = "Instant Z: " .. event.zInstant
	if event.isShake == true then
		shakeIndicator:setFillColor(1, 0, 0)
	else
		shakeIndicator:setFillColor(0, 0, 0)
	end
end

system.setAccelerometerInterval(60)
Runtime:addEventListener("accelerometer", onAccelerate)