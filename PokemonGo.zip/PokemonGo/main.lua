-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250, 500, 500, 1000)

local currentLocation =
{
	latitude = 0,
	longitude = 0,
}

local function locationHandler(event)
	if event then
		currentLocation.latitude = event.latitude
		currentLocation.longitude = event.longitude
		myMap:setRegion(event.latitude, event.longitude, 0.1, 0.1)
	end
end

local function mapMarker(event)
	Runtime:addEventListener("location", locationHandler)
	--for i=0,3 do
		math.randomseed( os.time() )
		local randImgNum = math.random(1, 150)
		if randImgNum < 10 then
			randImgNum = "00" .. randImgNum
		elseif randImgNum < 100 then
			randImgNum = "0" .. randImgNum
		end
		
		local randLat = math.random(-10, 10)
		local randLong = math.random(-10, 10)
		
		myMap:addMarker(currentLocation.latitude + randLat, currentLocation.longitude + randLong, { 
			imageFile = "material/images/d" .. randImgNum	 .. ".png"
		})
	--end
end

if myMap then
	myMap.mapType = "normal"
	timer.performWithDelay(500, mapMarker)
end
