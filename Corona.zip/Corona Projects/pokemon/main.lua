-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
display.setStatusBar( display.DefaultStatusBar )

--MAP

local myMap = native.newMapView( 250, 450, 500, 900 )
myMap.x = display.contentCenterX
local attempts = 0
local locationText = display.newText( "Location: ", 0, 400, native.systemFont, 16 )
locationText.anchorY = 0
locationText.x = display.contentCenterX
local distance = native.newTextBox( display.contentCenterX, 450, 300, 25 )
local text = native.newTextBox( display.contentCenterX, 500, 300, 25 )
--local text= display.newText( "???", 450, 40, native.SystemFont, 32)
--local text = display.newTextField( 250, 950, 500, 300 )

--[[
local options ={
      title = "Displayed Title",
      subtitle = "Subtitle text",
      listener = markerListener,
      imageFile =  "image.png",
    }
local function mapmarker (event)
  local opt1 =
  {
    title = "Chick-fil-A",
    subtitle = "Discount in Monday evening",
  }
  myMap:addMarker(34.06327,-118.445130, opt1)
end
--]]

local function locationHandler( event )
    local currentLocation = myMap:getUserLocation()
    if ( currentLocation.errorCode or ( currentLocation.latitude == 0 and currentLocation.longitude == 0 ) ) then
        locationText.text = currentLocation.errorMessage
        attempts = attempts + 1
        if ( attempts > 10 ) then
            native.showAlert( "No GPS Signal", "Can't sync with GPS.", { "Okay" } )
        else
            timer.performWithDelay( 1000, locationHandler )
        end
    else
      locationText.text = "Current location: " .. currentLocation.latitude .. "," .. currentLocation.longitude
      myMap:setCenter( currentLocation.latitude, currentLocation.longitude )
      myMap:addMarker( currentLocation.latitude, currentLocation.longitude)
    end
end

--POKEMON
--local markerID = 0
local thresh = 0
local function spawn( event )
  --local currentLocation = myMap:getUserLocation()
  currentLocation = event
  if currentLocation and thresh<5 then
    --newLat = math.random( (currentLocation.latitude - 0.001) , (currentLocation.latitude + 0.001) )
    --newLon = math.random( (currentLocation.longitude - 0.001) , (currentLocation.longitude + 0.001) )
    newLat = currentLocation.latitude + (math.random() * 2 - 1) * 0.001
    newLon = currentLocation.longitude + (math.random() * 2 - 1) * 0.001
    myMap:removeAllMarkers()
    myMap:addMarker(
      newLat,
      newLon,
      --currentLocation.latitude,
      --currentLocation.longitude,
      {imageFile = "image.png"}
    )
    thresh = thresh + 1
    --markerID = myMap:addMarker(event.latitude, event.longitude, options)
    text.text = '(' .. newLat .. ", " .. newLon .. ")"
    distance.text = 111320 * (math.sqrt(((newLat - currentLocation.latitude)^2) + ((newLon - currentLocation.longitude)^2))) 
  end
end

--ERROR
local function myUnhandledErrorListener( event )

    local iHandledTheError = true

    if iHandledTheError then
        print( "Handling the unhandled error", event.errorMessage )
    else
        print( "Not handling the unhandled error", event.errorMessage )
    end
    return iHandledTheError
end

--execute
if myMap then
  myMap.mapType = "normal"
  --timer.performWithDelay( 5000, mapmarker)
  ---timer.performWithDelay( 2000, locationHandler)
  --timer.performWithDelay( 3000, spawn, 0)
end
Runtime:addEventListener("location", spawn)

--Runtime:addEventListener("unhandledError", myUnhandledErrorListener)
