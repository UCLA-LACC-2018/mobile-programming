-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

local background = display.newImageRect( "images.jpg", 1000, 1000 )
background.x = display.contentCenterX +100
background.y = display.contentCenterY

local background = display.newImageRect( "download.png", 1000, 1000 )
background.x = display.contentCenterX
background.y = display.contentCenterY

local rect = background
rect.xScale = -1
rect:setFillColor( 1,1,1 )
local function autism()
  transition.to(rect, {rotation = rect.rotation-360,time=600,} )
  end
local function epilepsy()
  transition.to( rect.fill, { r= .9, g=math.random( .2, .9), b=math.random( .2, .9 ), a= 1, time=140, transition=easing.inCubic, })
  transition.to( rect.fill, { r= math.random( .2, .9 ), g=.9, b=math.random( .2, .9 ), a= 1, time=140, transition=easing.inCubic, })
  transition.to( rect.fill, { r= math.random( .2, .9 ), g=math.random( .2, .9), b=.9, a= 1, time=140, transition=easing.inCubic, })
  end

--epilepsy(math.random(0,1))
timer.performWithDelay( 100, epilepsy, 0 )  -- Repeat forever
timer.performWithDelay( 100, autism, 0 )
