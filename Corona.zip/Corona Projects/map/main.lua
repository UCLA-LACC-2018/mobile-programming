-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
display.setStatusBar( display.DefaultStatusBar )

local myMap = native.newMapView( 250, 500, 500, 1000 )
myMap.x = display.contentCenterX
local attempts = 0
local locationText = display.newText( "Location: ", 0, 400, native.systemFont, 16 )
locationText.anchorY = 0
locationText.x = display.contentCenterX

local function mapmarker (event)
  local opt1 =
  {
    title = "Chick-fil-A",
    subtitle = "Discount in Monday evening",
  }
  myMap:addMarker(34.06327,-118.445130, opt1)
end

local function locationHandler( event )
    local currentLocation = myMap:getUserLocation()

    if ( currentLocation.errorCode or ( currentLocation.latitude == 0 and currentLocation.longitude == 0 ) ) then
        locationText.text = currentLocation.errorMessage
        attempts = attempts + 1
        if ( attempts > 10 ) then
            native.showAlert( "No GPS Signal", "Can't sync with GPS.", { "Okay" } )
        else
            timer.performWithDelay( 1000, locationHandler )
        end

    else
        locationText.text = "Current location: " .. currentLocation.latitude .. "," .. currentLocation.longitude
        myMap:setCenter( currentLocation.latitude, currentLocation.longitude )
        myMap:addMarker( currentLocation.latitude, currentLocation.longitude )
    end
end



if myMap then
  myMap.mapType = "normal"
  timer.performWithDelay( 5000, mapmarker)
  timer.performWithDelay( 5000, locationHandler)

end
