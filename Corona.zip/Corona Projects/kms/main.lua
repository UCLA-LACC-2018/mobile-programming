-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
system.setAccelerometerInterval( 60 )
local background = display.newImageRect( "images.jpg", 1000, 1000 )
background.x = display.contentCenterX
background.y = display.contentCenterY
background:setFillColor(0,0,1)

local textGravX= display.newText( "???", 450, 40, native.SystemFont, 22)
local textGravY= display.newText( "???", 450, 40, native.SystemFont, 22)
local textGravZ= display.newText( "???", 450, 40, native.SystemFont, 22)
local textInstantX= display.newText( "???", 450, 40, native.SystemFont, 22)
local textInstantY= display.newText( "???", 450, 40, native.SystemFont, 22)
local textInstantZ= display.newText( "???", 450, 40, native.SystemFont, 22)

textGravX.x = 200
textGravX.y = 0

textGravY.x = 200
textGravY.y = 100

textGravZ.x = 200
textGravZ.y = 200

textInstantX.x = 200
textInstantX.y = 300

textInstantY.x = 200
textInstantY.y = 400

textInstantZ.x = 200
textInstantZ.y = 500

local onAccelerate = function (event)
  textGravX.text = "Gravity X: " .. event.xGravity
  textGravY.text = "Gravity Y: " .. event.yGravity
  textGravZ.text = "Gravity Z: " .. event.zGravity
  textInstantX.text = "Instant X: " .. event.xInstant
  textInstantY.text = "Instant Y: " .. event.yInstant
  textInstantZ.text = "Instant Z: " .. event.zInstant
  if event.isShake == true then
    --toggleColor()
    background:setFillColor(math.random( .2, 1 ),math.random( .2, 1 ),math.random( .2, 1 ))
  else
    background:setFillColor(math.random( .2, 1 ),math.random( .2, 1 ),math.random( .2, 1 ))
  end
end

Runtime:addEventListener("accelerometer", onAccelerate)
