-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
display.setDefault( "background", 0.9, 0.9, .9 )
local widget = require("widget")
display.setStatusBar( display.DefaultStatusBar )

local rect = display.newRect(160, 100, 300, 300)
rect:setFillColor(0.2, .5, 0.2)

local input = native.newTextBox( 160, 100, 300, 300 )
input.isEditable = true
input:setTextColor ( 0,0,0 )
input.hasBackground = false

local filePath = system.pathForFile( "data.txt", system.DocumentsDirectory)

local fileLoadHandler= function(event)
  print("fileLoadHandle")
  local file = io.open(filePath, "r")
  if file then
    local content = file:read("*a")
    io.close(file)
    input.text = content
  end
end

local fileSaveHandler = function(event)
  local file = io.open(filePath, "w")
  if file then
    local content = file:write(input.text)
    io.close(file)
    --local content = (" ")
    --input.text = content
      --local content = file:write(input.text)
      --io.close(file)
  end
end

local buttonLoad = widget.newButton{
  label = "Load",
  shape = "Circle",
  fontSize = 20,
  font = native.SystemFont,
  radius = 35,
  onRelease = fileLoadHandler,
}

buttonLoad.x = 270
buttonLoad.y = 350
buttonLoad:setFillColor(0.65, .1, 0.1)

local buttonSave = widget.newButton{
  label = "Save",
  shape = "Circle",
  fontSize = 20,
  font = native.SystemFont,
  radius = 35,
  onRelease = fileSaveHandler,
}
buttonSave.x = 200
buttonSave.y = 400
buttonSave:setFillColor(0.65, .1, 0.1)
