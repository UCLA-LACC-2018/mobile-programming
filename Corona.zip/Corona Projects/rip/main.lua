-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local background = display.newImageRect( "images.jpg", 1000, 1000 )
background.x = display.contentCenterX
background.y = display.contentCenter
background:setFillColor(0.997255, 0.0784, 0.960784)

local widget = require("widget")
display.setStatusBar(displayDefaultStatusBar)

local input1 = native.newTextField( 370, 80, 230, 40 )
local input2 = native.newTextField( 370, 180, 230, 40 )
local flatRect = display.newRect(250,240,480,5)


--local epilepsy = function(event)
---system.setAccelerometerInterval( 60 )
local onAccelerate = function (event)
  ---if event.isShake == true then
    --toggleColor()
    ---flatRect:setFillColor(math.random( .2, 1 ),math.random( .2, 1 ),math.random( .2, 1 ),200)
  ---else
    ---flatRect:setFillColor(math.random( .2, 1 ),math.random( .2, 1 ),math.random( .2, 1 ),200)
  flatRect:setFillColor(math.random( .2, .9 ),math.random( .2, .9 ),math.random( .2, .9 ))
  ---end
end
---Runtime:addEventListener("accelerometer", onAccelerate)
timer.performWithDelay(150, onAccelerate, 0)
--end

local textAnswer= display.newText( "???", 450, 40, native.SystemFont, 32)
textAnswer.x = 250
textAnswer.y = 270

----
local addHandler = function(event)
  textAnswer.text = input1.text + input2.text
  --textAnswer= print.newText( input1.text + input2.text, 450, 40, native.SystemFont, 32)
end

local subHandler = function(event)
  textAnswer.text = input1.text - input2.text
  --textAnswer= print.newText( input1.text + input2.text, 450, 40, native.SystemFont, 32)
end

local prodHandler = function(event)
  textAnswer.text = input1.text * input2.text
  --textAnswer= print.newText( input1.text + input2.text, 450, 40, native.SystemFont, 32)
end

local divHandler = function(event)
  textAnswer.text = input1.text / input2.text
  --textAnswer= print.newText( input1.text + input2.text, 450, 40, native.SystemFont, 32)
end
----

local button1 = widget.newButton
{
  label = "+",
  shape = "roundedRect",
  fillColor =
  {
    default = {0.9, 0.95, 0.5},
    over = {0.6, 0.9, 0.9},
  },
  labelColor =
  {
    default = {.4,.31,.91},
  },
  fontSize = 22,
  font = native.systemFont,
  onRelease = addHandler,
  width = 45,
}

local button2 = widget.newButton
{
  label = "-",
  shape = "roundedRect",
  fillColor =
  {
    default = {0, 1, 0},
    over = {0.9, 0.6, 0.9},
  },
  labelColor =
  {
    default = {.9,.11,.21},
  },
  fontSize = 22,
  font = native.systemFont,
  onRelease = subHandler,
  width = 45,
}

local button3 = widget.newButton
{
  label = "x",
  shape = "roundedRect",
  fillColor =
  {
    default = {0.46, 0.95, 0.95},
    over = {0.9, 0.9, 0},
  },
  labelColor =
  {
    default = {.1,.91,.21},
  },
  fontSize = 22,
  font = native.systemFont,
  onRelease = prodHandler,
  width = 45,
}

local button4 = widget.newButton
{
  label = "/",
  shape = "roundedRect",
  fillColor =
  {
    default = {1, 0, 0.15},
    over = {0.6, 0.9, 0.9},
  },
  labelColor =
  {
    default = {.21,.71,.91},
  },
  fontSize = 22,
  font = native.systemFont,
  onRelease = divHandler,
  width = 45,
}

button1.x = 30
button1.y = 160
button2.x = 80
button2.y = 160
button3.x = 130
button3.y = 160
button4.x = 180
button4.y = 160

--timer.performWithDelay( 200, epilepsy, 0 )
--timer.performWithDelay( 100, epilepsy, 0 )  -- Repeat forever


local function myUnhandledErrorListener( event )

    local iHandledTheError = true

    if iHandledTheError then
        print( "Handling the unhandled error", event.errorMessage )
    else
        print( "Not handling the unhandled error", event.errorMessage )
    end

    return iHandledTheError
end

Runtime:addEventListener("unhandledError", myUnhandledErrorListener)
