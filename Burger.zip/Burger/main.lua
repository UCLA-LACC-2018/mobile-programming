-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView( 250, 500, 500, 1000 )
local function mapmarker( event )
	local opt1 =
	{
		title = "In-n-out"
		
}
myMap: addMarker(34.0631, -118.4481, opt1 )

	local opt2 =
	{
		title = "Fatburger"
		
}
myMap: addMarker(34.0602, -118.4469, opt2 )
end

if myMap then
	myMap.mapType = "normal"

	timer.performWithDelay( 5000, mapmarker )
end
