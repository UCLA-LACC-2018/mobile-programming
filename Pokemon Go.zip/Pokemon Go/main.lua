-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local myMap = native.newMapView( 250, 500, 500, 1000 )


local getFirstLocation = false

local function locationHandler(event)
	if getFirstLocation == false then 
	myMap: setRegion(event.latitude, event.longitude, .1, .1)
	getFirstLocation = true
	end
end

local function mapmarker(event)

	local poke1 = 
	{
		imageFile = "039.png"
	}
	myMap:addMarker(34.063327, -118.445130, poke1 )


	local poke2 = 
	{
		imageFile = "143.png"
	}
	myMap:addMarker(34.063327, -118.445130, poke2 )




	if myMap then 
		myMap.mapType = "normal"

		timer.performWithDelay( 5000, mapmarker )
end
