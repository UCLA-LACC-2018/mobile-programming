-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require("widget")

local input1 = native.newTextField(250, 400, 200, 40)
local input2 = native.newTextField(250, 500, 200, 40)

local answerText = display.newText("???", 200, 40, native.systemFont, 32)
answerText.x = 250
answerText.y = 600

local addHandler = function(event)
	answerText.text = input1.text + input2.text
end

local button1 = widget.newButton
{
	label = "+",
	shape = "roundRect",
	fontSize = 22,
	font = native.systemFont,
	onRelease = addHandler,
}