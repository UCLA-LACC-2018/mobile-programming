-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require("widget")

display.setStatusBar(display.DefaultStatusBar)

input = native.newTextBox(250, 420, 480, 750)
input.isEditable = true
input.font = native.newFont(native.systemFont, 20)

local filePath = system.pathForFile("data.text", system.DocumentsDirectory)

local fileLoadHandler = function(event)
	local file = io.open(filePath, "r")
	if file then
		local content = file:read("*a")
		io.close(file)
		input.text = content
	end
end

local fileSaveHandler = function(event)
	local file = io.open(filePath, "w")
	if file then
		local content = file:write(input.text)
		io.close(file)
	end
end

local buttonLoad = widget.newButton
{
	label = "Load",
	shape = "roundedRect",
	fontSize = 22,
	font = native.systemFont,
	onRelease = fileLoadHandler,
}

buttonLoad.x = 125
buttonLoad.y = 875

local buttonSave = widget.newButton
{
	label = "Save",
	shape = "roundedRect",
	fontSize = 22,
	font = native.systemFont,
	onRelease = fileSaveHandler,
}

buttonSave.x = 375
buttonSave.y = 875