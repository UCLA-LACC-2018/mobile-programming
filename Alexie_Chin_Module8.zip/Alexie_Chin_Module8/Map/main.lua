-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250, 500, 500, 1000)

local function mapmarker(event)
	local opt1 =
	{
		title = "Honeyboba"
	}
	myMap:addMarker(33.9738774, -118.4831446, opt1)
end

if myMap then
	myMap.mapType = "normal"
	timer.performWithDelay(5000, mapmarker)
end

local function locationEventHandler(event)
	if event then
		myMap:setRegion(event.latitude, event.longitude)
	end
end