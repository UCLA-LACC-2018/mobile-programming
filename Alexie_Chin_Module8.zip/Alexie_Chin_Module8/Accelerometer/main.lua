-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

system.setAccelerometerInterval(60)

local textGravX = display.newText("???", 200, 40, native.systemFont, 32)
textGravX.x = 250
textGravX.y = 250

local textGravY = display.newText("???", 200, 40, native.systemFont, 32)
textGravY.x = 250
textGravY.y = 350

local textGravZ = display.newText("???", 200, 40, native.systemFont, 32)
textGravZ.x = 250
textGravZ.y = 450

local textInstantX = display.newText("???", 200, 40, native.systemFont, 32)
textInstantX.x = 250
textInstantX.y = 550

local textInstantY = display.newText("???", 200, 40, native.systemFont, 32)
textInstantY.x = 250
textInstantY.y = 650

local textInstantZ = display.newText("???", 200, 40, native.systemFont, 32)
textInstantZ.x = 250
textInstantZ.y = 750

local onAccelerate = function(event)
	textGravX.text = "Gravity X: " .. event.xGravity
	textGravY.text = "Gravity Y: " .. event.yGravity
	textGravZ.text = "Gravity Z: " .. event.xGravity
	textInstantX.text = "Instant X: " .. event.xInstant
	textInstantY.text = "Instant Y: " .. event.yInstant
	textInstantZ.text = "Instant Z: " .. event.zInstant
end

Runtime:addEventListener("accelerometer", onAccelerate)