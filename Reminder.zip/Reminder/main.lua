-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = ("widget")

input = native.newTextBox( 250, 280, 480, 480)
input.isEditable = true 
local filePath = system.pathForFile("data.txt", system.DocumentsDirectory)

local fileReadHandler = function(event)
	local file = io.open(filePath, "r")
	if file then
		local content = file:read("*a")
		io.close(file)
		input.text = content
	end
end

local fileSaveHandler = function(event)
	local file = io.open(filePath, "w")
	if file then
		local content = file:write("*a")
		io.close(file)
		input.text = content

	end
end

local button1 = widget.newButton
{
	label = "Save",
	shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
	   over = {0.6, 0.6, 0.6},
	 },
	 labelColor =
 	 {
		default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = fileSaveHandler, 
	 width = 45,
}

local button2 = widget.newButton
{
	label = "Load",
	shape = "roundedRect",
        fillColor =
        {
           default = {0.5, 0.5, 0.5},
	   over = {0.6, 0.6, 0.6},
	 },
	 labelColor =
 	 {
		default = {1, 1, 1},
         },
         fontSize = 22,
         font = native.SytemFont,
         onRelease = fileReadHandler, 
	 width = 45,
}

button1.x = 400
button1.y = 600

button2.x = 100
button2.y = 600



