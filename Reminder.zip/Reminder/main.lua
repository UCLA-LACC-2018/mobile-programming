-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")

local input = native.newTextBox(250, 280, 480, 480)
input.isEditable = true

local filePath = system.pathForFile("data.txt", system.DocumentsDirectory)

local saveHandler = function(event)
	local file = io.open(filePath, "w")
	if file then
		file:write(input.text)
		io.close(file)
	end
end

local saveButton = widget.newButton
{
	label = "Save",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = saveHandler,
	width = 100,
}

saveButton.x = 100
saveButton.y = 600

local loadHandler = function(event)
	local file = io.open(filePath, "r")
	if file then
		local content = file:read("*a")
		io.close(file)
		input.text = content
	end
end

local loadButton = widget.newButton
{
	label = "Load",
	shape = "roundedRect",
	fillColor =
	{
		default = {0.5, 0.5, 0.5},
		over = {0.6, 0.6, 0.6},
	},
	labelColor =
	{
		default = {1, 1, 1},
	},
	fontSize = 22,
	font = native.systemFont,
	onRelease = loadHandler,
	width = 100,
}

loadButton.x = 300
loadButton.y = 600