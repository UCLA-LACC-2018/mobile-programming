-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250, 500, 500, 1000)

local function locationHandler(event)
	if event then
		myMap:setRegion(event.latitude, event.longitude, 0.1, 0.1)
	end
end

local function mapMarker(event)
	local opt1 =
	{
		title = "In-N-Out",
		subtitle = "Classic California-based burger chain",
	}
	myMap:addMarker(34.0623522, -118.4483374, opt1)
	
	local opt2 =
	{
		title = "Diddy Reese",
		subtitle = "Cookies and ice cream",
	}
	myMap:addMarker(34.0623548,-118.4475636, opt2)
	Runtime:addEventListener("location", locationHandler)
end

if myMap then
	myMap.mapType = "normal"
	timer.performWithDelay(500, mapMarker)
end
