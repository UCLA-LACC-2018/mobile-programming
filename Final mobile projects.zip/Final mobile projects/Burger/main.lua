-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250, 500, 500, 1000)



local function locationHandler(event)
  myMap:setRegion(event.latitude, event.longitude, .1, .1)
end

local function mapmarker(event)
  local opt1=
  {
    title = "In N Out",
    subtitle = "good",
  }
  local opt2 =
  {
    title = "Diddy Riese",
    sub = "good ice cream",
  }
  myMap:addMarker(34.063071,-118.448026, opt1)
  myMap:addMarker(34.063058, -118.440224 ,opt2)
  Runtime:addEventListener("location", locationHandler)
end


if myMap then
  myMap.mapType = "normal"
  timer.performWithDelay(5000, mapmarker)
end
