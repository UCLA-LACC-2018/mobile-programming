-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local textGravX = display.newText("???", 250, 80, native.systemFont, 32)
textGravX.y = 70
textGravX.x = 90

local textGravY = display.newText("???", 250, 80, native.systemFont, 32)
textGravY.y = 120
textGravY.x = 90

local textGravZ = display.newText("???", 250, 80, native.systemFont, 32)
textGravZ.y = 170
textGravZ.x = 90

local textInstantX = display.newText("???", 250, 80, native.systemFont, 32)
textInstantX.y = 220
textInstantX.x = 90

local textInstantY = display.newText("???", 250, 80, native.systemFont, 32)
textInstantY.y = 270
textInstantY.x = 90

local textInstantZ = display.newText("???", 250, 80, native.systemFont, 32)
textInstantZ.y = 320
textInstantZ.x = 90


system.setAccelerometerInterval(60)

local onAccelerate = function(event)
  textGravX.text = "Gravity X: " .. event.xGravity
  textGravY.text = "Gravity Y: " .. event.yGravity
  textGravZ.text = "Gravity Z: " .. event.zGravity
  textInstantX.text = "Instant X: " .. event.xInstant
  textInstantY.text = "Instant Y: " .. event.yInstant
  textInstantZ.text = "Instant Z: " .. event.zInstant
end


Runtime:addEventListener("accelerometer", onAccelerate)
