-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250, 500, 500, 1000)


local getFirstLocation = false

local function locationHandler(event)
  if getFirstLocation == false then
    myMap:setRegion(event.latitude, event.longitude, .1, .1)
    getFirstLocation = true
  end
end

local function mapmarker(event)
  local poke1=
  {
    imageFile = "c039.png",
  }
  myMap:addMarker(34.063071,-118.448026, poke1) -- in n out
  local poke2=
  {
    imageFile = "c143.png",
  }
  myMap:addMarker(34.0690886,-118.4435659, poke2) -- our building

  local poke3=
  {
    imageFile = "c141.png",
  }
  myMap:addMarker(34.0669,-118.4399, poke3) -- taco bell

  local poke4=
  {
    imageFile = "c145.png",
  }
  myMap:addMarker(34.06984, -118.45397, poke4) -- apartment

  local poke5=
  {
    imageFile = "c150.png",
  }
  myMap:addMarker(34.063058,-118.440224, poke5) -- chick fil a

  Runtime:addEventListener("location", locationHandler)
end

if myMap then
  myMap.mapType = "normal"
  timer.performWithDelay(5000, mapmarker)
end
