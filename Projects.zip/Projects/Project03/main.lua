-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here
local widget = require("widget")
input = native.newTextBox(250,280,480,480)
input.font = native.newFont(native.systemFont, 32)
input.isEditable = true
local filePath = system.pathForFile("data.txt", system.DocumentsDirectory)

local fileLoadHandler = function(event)
	local file = io.open(filePath, 'r')
	if file then
		local content = file:read("*a")
		io.close(file)
		input.text = content
	end
end

local fileSaveHandler = function(event)
	local file = io.open(filePath, 'w')
	if file then 
		local content = file:write(input.text)
		io.close(file)
	end
end
local button1 = widget.newButton
{
	label = "Load",
	shape = "roundedRect",
	fillColor = 
	{
		default = {0.5,0.5,0.5},
		over = {0.6,0.6,0.6} ,
	},
	labelColor = 
	{
		default = {1,1,1},
	},
	fontSize = 22,
	font = native.SystemFont,
	onRelease = fileLoadHandler,
	width = 100,
}

button1.x = 100
button1.y = 600

local button2 = widget.newButton
{
	label = "Save",
	shape = "roundedRect",
	fillColor = 
	{
		default = {0.5,0.5,0.5},
		over = {0.6,0.6,0.6} ,
	},
	labelColor = 
	{
		default = {1,1,1},
	},
	fontSize = 22,
	font = native.SystemFont,
	onRelease = fileSaveHandler,
	width = 100,
}

button2.x = 400
button2.y = 600


input:addEventListener("userInput", fileSaveHandler)