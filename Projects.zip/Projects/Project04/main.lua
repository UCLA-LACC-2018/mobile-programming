-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local myMap = native.newMapView(250,500,500,1000)

local function mapmarker(event)
	local opt1 =
	{
		title = "In N Out",
		subtitle = "Lit animal style",
	}
	myMap:addMarker(34.063073, -118.448082)
end
if myMap then 
	myMap.mapType = "normal"
	
	timer.performWithDelay(5000,mapmarker)
end


	