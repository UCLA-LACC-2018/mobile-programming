-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

system.setAccelerometerInterval(60)

local textGravx = display.newText("???", 450,40, native.systemFont, 24)
textGravx.x = 100
textGravx.y = 100
local textGravy = display.newText("???", 450,40, native.systemFont, 24)
textGravy.x = 100
textGravy.y = 200
local textGravz = display.newText("???", 450,40, native.systemFont, 24)
textGravz.x = 100
textGravz.y = 300
local textInstantX = display.newText("???", 450,40, native.systemFont, 24)
textInstantX.x = 100
textInstantX.y = 400
local textInstantY = display.newText("???", 450,40, native.systemFont, 24)
textInstantY.x = 100
textInstantY.y = 500
local textInstantZ = display.newText("???", 450,40, native.systemFont, 24)
textInstantZ.x = 100
textInstantZ.y = 600

local shaker = display.newRect(100, 800,480,5)
shaker:setFillColor(1,1,1)

local toggleColor = function(event)
	
	shaker:setFillColor(0,1,0)
	shaker:setFillColor(0,0,1)
end
local counter = 0
local onAccelerate = function(event)
	textGravx.text = "Gravity X: " .. event.xGravity
	textGravy.text = "Gravity Y: " .. event.yGravity
	textGravz.text = "Gravity Z: " .. event.zGravity
	textInstantX.text = "Instant X: " .. event.xInstant
	textInstantY.text = "Instant Y: " .. event.yInstant
	textInstantZ.text = "Instant Z: " .. event.zInstant
	if event.isShake == true and counter % 2 == 0 then
		shaker:setFillColor(1,1,0)
		counter = counter + 1
	elseif event.isShake == true and counter % 2 == 1 then
		shaker:setFillColor(1,1,1)
		counter = counter + 1
	end
end

Runtime:addEventListener("accelerometer", onAccelerate)

