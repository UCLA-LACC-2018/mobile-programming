-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- Your code here

local widget = require("widget")

--Map start
local myMap = native.newMapView(250,500,500,1000)

local x = false

local function locationHandler(event)
	if x == false then
		myMap:setRegion(event.latitude,event.longitude,.1,.1)
		x = true
	end
end

local function mapmarker(event)
	local opt1 =
	{
		imageFile = "c001.png"
	}
	myMap:addMarker(34.063073, -118.448082, opt1)
	
	Runtime:addEventListener("location", locationHandler)
end
if myMap then 
	myMap.mapType = "normal"
	timer.performWithDelay(5000,mapmarker)
end
--Map end

--LOAD AND SAVE Start

--LOAD AND SAVE End




--Acceleratometer Start

--Acceleratometer End